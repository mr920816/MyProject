ASP.NET Boilerplate - Module Zero - Startup Template
----------------------------------------------------

This project is aimed to be a starter template for ABP and module zero.
You can create your project on http://www.aspnetboilerplate.com/Templates
