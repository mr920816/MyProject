﻿namespace MyProject_Mvc5.x_ar
{
    public class x_arConsts
    {
        public const string LocalizationSourceName = "x_ar";

        public const bool MultiTenancyEnabled = true;
    }
}