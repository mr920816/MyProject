﻿namespace MyProject_Mvc5.x_ar.Configuration
{
    public static class AppSettingNames
    {
        public const string UiTheme = "App.UiTheme";
    }
}
