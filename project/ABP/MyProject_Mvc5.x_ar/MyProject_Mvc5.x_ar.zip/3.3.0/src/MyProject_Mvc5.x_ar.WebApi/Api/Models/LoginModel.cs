﻿using System.ComponentModel.DataAnnotations;

namespace MyProject_Mvc5.x_ar.Api.Models
{
    public class LoginModel
    {
        public string TenancyName { get; set; }

        [Required]
        public string UsernameOrEmailAddress { get; set; }

        [Required]
        public string Password { get; set; }
    }
}