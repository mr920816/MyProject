﻿namespace MyProject_Mvc5.x_ar.Authorization.Accounts.Dto
{
    public class RegisterOutput
    {
        public bool CanLogin { get; set; }
    }
}