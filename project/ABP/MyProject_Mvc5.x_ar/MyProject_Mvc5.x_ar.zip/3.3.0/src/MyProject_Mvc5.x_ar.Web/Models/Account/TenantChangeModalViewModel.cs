﻿namespace MyProject_Mvc5.x_ar.Web.Models.Account
{
    public class TenantChangeModalViewModel
    {
        public string TenancyName { get; set; }
    }
}